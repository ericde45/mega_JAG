A total conversion of the ST CONNEXION Demo - Let's Do The Twist Again - to the Atari Jaguar

original credits:
Coding: Alien
Graphics: Krazy Rex
Music: Celtics

using LSP by Arnaud Carré : https://github.com/arnaud-carre/LSPlayer ported to Atari Jaguar

complete source of this demo is available at https://github.com/ericde45/mega_JAG

Thanks to CyranoJ, Dilinger, Zerosquare, SCPCD, Fadest, 42bs for technical support and good advices

Thanks to Dyno & WAB.COM for the graphics assets and scrolltext.
Curves are coming directly from the ST


No 68000 !
No Blitter !
GPU & DSP only.


